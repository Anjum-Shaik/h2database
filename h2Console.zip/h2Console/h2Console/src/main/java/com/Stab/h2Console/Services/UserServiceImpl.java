package com.Stab.h2Console.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Stab.h2Console.Models.Users;
import com.Stab.h2Console.Repository.UserRepo;
import com.Stab.h2Console.Response.ServiceStatus;

@Service
public class UserServiceImpl implements UserService{

    @Autowired private UserRepo userRepo;

    @Override
    public ResponseEntity<ServiceStatus> saveUserData(Users users) {
        Users data = userRepo.save(users);
        if(!data.equals(null))
        {
            return new ResponseEntity<>(ServiceStatus.builder().statusCode(200).statusMessage("User Details Saved").build(),HttpStatus.OK);
        }
        else
        {
            return new ResponseEntity<>(ServiceStatus.builder().statusCode(0).statusMessage("Please Fill Correct Data").build(),HttpStatus.OK);
        }
    }

    @Override
    public List<Users> getData() {
        List<Users> usersData = userRepo.findAll();
        if(!usersData.isEmpty())
        {
            return usersData;
        }
        else
        {
            return null;
        }
    }

    @Override
    public Optional<Users> getUserDataById(Long id) {
        Optional<Users> userById = userRepo.findById(id);
        if(userById.isPresent())
        {
            return userById;
        }
        else
        {
            return null;
        }
    }

    @Override
    public String deleteUserById(Long id) {
        userRepo.deleteById(id);
        return "Data deleted";
    }
    
}
