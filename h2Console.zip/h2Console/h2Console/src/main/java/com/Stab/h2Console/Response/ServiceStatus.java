package com.Stab.h2Console.Response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ServiceStatus {
    private int statusCode;
    private String statusMessage;
    // private Object statusObject;
}
