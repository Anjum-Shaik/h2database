package com.Stab.h2Console.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Stab.h2Console.Models.Users;

public interface UserRepo extends JpaRepository<Users, Long>{
    
}
