package com.Stab.h2Console.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.Stab.h2Console.Models.Users;
import com.Stab.h2Console.Response.ServiceStatus;

public interface UserService {

    public ResponseEntity<ServiceStatus> saveUserData(Users users);

    public List<Users> getData();

    public Optional<Users> getUserDataById(Long id);

    public String deleteUserById(Long id);

}
