package com.Stab.h2Console;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2ConsoleApplicationTests {

	@Test
	void contextLoads() {
	}

}
